This is an example long description for tests to load.

This file is `valid reStructuredText
<http://docutils.sourceforge.net/docs/ref/rst/restructuredtext.html>`_.
